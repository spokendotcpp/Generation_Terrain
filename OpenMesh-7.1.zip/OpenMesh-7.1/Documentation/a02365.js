var a02365 =
[
    [ "HeapInterface", "a02369.html", "a02369" ],
    [ "CollapseInfo", "a02365.html#ac4bc78e9bb2a26693eda5ad817dd8308", null ],
    [ "DeciHeap", "a02365.html#a22d1340e2ee838d396a6aba82135e4c9", null ],
    [ "HalfedgeHandle", "a02365.html#a6214e337d0b42e74ef2f8ec93b67319d", null ],
    [ "Mesh", "a02365.html#a3c5207a20bd2e5adfd2bb35f82719694", null ],
    [ "Module", "a02365.html#a2c16ba0c94ecaa849bfdfa31148ac5ff", null ],
    [ "ModuleList", "a02365.html#a0846b1d3f4ac5dc6a1aa32a9e7efc7b6", null ],
    [ "ModuleListIterator", "a02365.html#a7d925514a38016c7bd90b4047655f0cc", null ],
    [ "Self", "a02365.html#a56387852bafbda2cd245b08ea2d0008e", null ],
    [ "VertexHandle", "a02365.html#a45a4df1d970e4d3ed619029ea80fe30f", null ],
    [ "DecimaterT", "a02365.html#acf185e9dd3958b8634d26ff322f80685", null ],
    [ "~DecimaterT", "a02365.html#a6d1b1b6855f42b5501860ae79cf6be64", null ],
    [ "decimate", "a02365.html#ae68360f349a3aeb6b8a01a7ea4af7ea3", null ],
    [ "decimate_to", "a02365.html#a314edcd690ba54b6b77dde411e04262a", null ],
    [ "decimate_to_faces", "a02365.html#a3f9e5d0abce8d73b67cf2bbf17700241", null ]
];