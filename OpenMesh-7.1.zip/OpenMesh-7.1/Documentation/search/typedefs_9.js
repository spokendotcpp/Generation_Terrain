var searchData=
[
  ['quadricd',['Quadricd',['../a00155.html#a858c8f4cd938b217a26ef480af3fba39',1,'OpenMesh::Geometry']]],
  ['quadricf',['Quadricf',['../a00155.html#ad75ef49af7bc4d049924402a82fafd2b',1,'OpenMesh::Geometry']]]
];
