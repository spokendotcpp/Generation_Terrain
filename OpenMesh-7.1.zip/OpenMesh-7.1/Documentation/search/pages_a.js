var searchData=
[
  ['some_20words_20on_20the_20c_2b_2b_20implementation',['Some words on the C++ implementation',['../a03929.html',1,'additional_information']]],
  ['some_20basic_20operations_3a_20flipping_20and_20collapsing_20edges',['Some basic operations: Flipping and collapsing edges',['../a03938.html',1,'mesh_docu']]],
  ['some_20notes_20on_20how_20to_20speedup_20openmesh',['Some Notes on how to speedup OpenMesh',['../a03940.html',1,'additional_information']]],
  ['specifying_20your_20mymesh',['Specifying your MyMesh',['../a03932.html',1,'mesh_docu']]],
  ['smoother_20tools',['Smoother Tools',['../a03939.html',1,'tools_docu']]],
  ['sudivision_20tools',['Sudivision Tools',['../a03941.html',1,'tools_docu']]],
  ['storing_20custom_20properties',['Storing custom properties',['../a03952.html',1,'tutorial']]]
];
