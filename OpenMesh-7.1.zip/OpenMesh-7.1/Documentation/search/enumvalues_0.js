var searchData=
[
  ['binary',['Binary',['../a01949.html#a9f4f797b08c045b611eaa6f8d149da21a5cb7f45e7ba928e0a23e4a676d10fa8a',1,'OpenMesh::IO::Options']]]
];
