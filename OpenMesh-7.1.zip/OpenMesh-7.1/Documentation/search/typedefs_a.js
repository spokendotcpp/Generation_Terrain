var searchData=
[
  ['refs',['Refs',['../a01797.html#a1e5f6c61e62ce8fcf6e05ecfa22d76e8',1,'OpenMesh::Concepts::MeshItems::VertexT::Refs()'],['../a01801.html#aa34c7febe7e05c45e9234e66d740b842',1,'OpenMesh::Concepts::MeshItems::HalfedgeT::Refs()'],['../a01805.html#af0ee51596f4578845a761f1e8163af06',1,'OpenMesh::Concepts::MeshItems::EdgeT::Refs()'],['../a01809.html#abaa2dcfa0a57e6cf656f86d8ed312396',1,'OpenMesh::Concepts::MeshItems::FaceT::Refs()']]],
  ['rgb_5ft',['rgb_t',['../a01179.html#a2a140b5cbe91a0072d5b4d1da68e4190',1,'OpenMesh::IO']]],
  ['rgba_5ft',['rgba_t',['../a01179.html#a3dfc456791ee5d8699997d585f10b4f7',1,'OpenMesh::IO']]]
];
