var searchData=
[
  ['importert',['ImporterT',['../a01941.html',1,'OpenMesh::IO']]],
  ['info',['Info',['../a02417.html',1,'OpenMesh::Decimater::ModProgMeshT']]],
  ['interpolatingsqrt3lgt',['InterpolatingSqrt3LGT',['../a02753.html',1,'OpenMesh::Subdivider::Uniform']]],
  ['iteratort',['IteratorT',['../a02153.html',1,'']]],
  ['itraits',['ITraits',['../a02125.html',1,'OpenMesh::FinalMeshItemsT']]]
];
