var searchData=
[
  ['laplacesmoothert',['LaplaceSmootherT',['../a02557.html',1,'OpenMesh::Smoother']]],
  ['longestedget',['LongestEdgeT',['../a02733.html',1,'OpenMesh::Subdivider::Uniform']]],
  ['loopschememaskt',['LoopSchemeMaskT',['../a01893.html',1,'OpenMesh']]],
  ['loopt',['LoopT',['../a02737.html',1,'OpenMesh::Subdivider::Uniform']]]
];
