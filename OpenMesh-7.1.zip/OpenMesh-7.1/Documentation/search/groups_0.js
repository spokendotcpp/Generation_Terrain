var searchData=
[
  ['interface_20concepts',['Interface Concepts',['../a01174.html',1,'']]]
];
