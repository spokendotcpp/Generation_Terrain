var searchData=
[
  ['facecolor',['FaceColor',['../a01949.html#a9f4f797b08c045b611eaa6f8d149da21a3e0b1cda32fe42bde7ac3dc96f977a46',1,'OpenMesh::IO::Options']]],
  ['facenormal',['FaceNormal',['../a01949.html#a9f4f797b08c045b611eaa6f8d149da21a20ffc1477fa85d5ba3623817f71d1b39',1,'OpenMesh::IO::Options']]],
  ['facetexcoord',['FaceTexCoord',['../a01949.html#a9f4f797b08c045b611eaa6f8d149da21a54ae741e612ef590c7040e6b80405539',1,'OpenMesh::IO::Options']]],
  ['feature',['FEATURE',['../a01181.html#af600bbf2c3f55c90a2a64848f0547617af9b7e330ca8bb23dc9d1d82f5e16db82',1,'OpenMesh::Attributes']]],
  ['fixednonmanifold',['FIXEDNONMANIFOLD',['../a01181.html#af600bbf2c3f55c90a2a64848f0547617a7ab3cc5eae1a983fe6815d01203d7047',1,'OpenMesh::Attributes']]]
];
