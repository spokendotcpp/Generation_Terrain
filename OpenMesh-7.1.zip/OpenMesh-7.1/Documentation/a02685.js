var a02685 =
[
    [ "~Coeff", "a02685.html#a2e5d8e614fa76d8b9814da81217f76f8", null ],
    [ "operator()", "a02685.html#ad2f19665418f3827ef929c6d8728af09", null ]
];