var a02805 =
[
    [ "VertexT", "a02809.html", "a02809" ],
    [ "VertexAttributes", "a02805.html#aac3340dc9eac0c0bbceadbce67c24a35a27d4d5477372347aca7261baabbabba7", null ],
    [ "HalfedgeAttributes", "a02805.html#a822b8cb7689b5f9998aa20a5dc5388daaab2c994340799eab00af080acf419892", null ],
    [ "EdgeAttributes", "a02805.html#ae1bba456e4ae884fe36323db88d16a8aa9a270cdd9bb89b4f3b227bdf5263d394", null ],
    [ "FaceAttributes", "a02805.html#a297892b3fc9b3f754e7d7b15cfc1fa17a29d6a5d6188fbdfacd26d642e5024e95", null ]
];