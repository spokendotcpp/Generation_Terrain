var a02713 =
[
    [ "compute_weight", "a02713.html#adf2bc905f8bc955c00a9b362b0f70f93", null ],
    [ "operator()", "a02713.html#add6b2b92d8b8ba0d8fe9335b4ceb1963", null ],
    [ "val_", "a02713.html#a5d608197835420b4c221b731673d3e3e", null ]
];