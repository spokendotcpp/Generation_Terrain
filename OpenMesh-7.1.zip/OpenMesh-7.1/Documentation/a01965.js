var a01965 =
[
    [ "_OMReader_", "a01965.html#a4f0de4a7adf41f0cdb8add4bac8da575", null ],
    [ "~_OMReader_", "a01965.html#a9b09b0181e0e637049090dd53f53b5c9", null ],
    [ "can_u_read", "a01965.html#a6cac287b1366fda5a9f8c23145fafba9", null ],
    [ "can_u_read", "a01965.html#aaca449c7bcb101b8f6b8b109d4868f12", null ],
    [ "get_description", "a01965.html#a9d793c33e44789239e12b8568fb7436a", null ],
    [ "get_extensions", "a01965.html#abc8aef97e6ffd9db30ec8f8418f86485", null ],
    [ "get_magic", "a01965.html#ab16d5b287c3617c3d7e00a307342f050", null ],
    [ "read", "a01965.html#a882837d0b59be32741d8d9e7578f3f62", null ],
    [ "read", "a01965.html#a9a4d62c85043026f4ce5a96ec8edda96", null ]
];