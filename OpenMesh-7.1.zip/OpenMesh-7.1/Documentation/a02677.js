var a02677 =
[
    [ "EdgeHandle", "a02677.html#a46e6197eae82c4592eb63179bb01cedf", null ],
    [ "EdgeIter", "a02677.html#a5c2d90f4bf6f7e1be995fee3bf2346f6", null ],
    [ "FaceHandle", "a02677.html#afb81aaa80c3dd00a71d6e9b027c3404f", null ],
    [ "FaceIter", "a02677.html#ab92e9e5aa0eef6d58957b8bb36e6420c", null ],
    [ "HalfedgeHandle", "a02677.html#ae6facaeec3c51f7d48b787b268cd611a", null ],
    [ "Normal", "a02677.html#ab02d527ddfeedd4cd7e99cfac3a40193", null ],
    [ "parent_t", "a02677.html#aedf4baed9240d00509d09c8d8faeb75c", null ],
    [ "Point", "a02677.html#a20beb79bd423930daa500e83354acb5a", null ],
    [ "VertexEdgeIter", "a02677.html#a490f5a58e50ed7ba81d86cd81ffd7c5e", null ],
    [ "VertexFaceIter", "a02677.html#adce13f2ef29ec027648ac8a11932885c", null ],
    [ "VertexHandle", "a02677.html#a16856045ea6cb81478200e338f70d7a0", null ],
    [ "VertexIter", "a02677.html#a2b348559c9f1453e1d1aed960b6e3080", null ],
    [ "VOHIter", "a02677.html#ab45a947fb39ce828de4242ddf1f8f0ef", null ],
    [ "CatmullClarkT", "a02677.html#ae6d980d140a5fa437cbd052cad08ad5b", null ],
    [ "CatmullClarkT", "a02677.html#a4dffc85efdd793bb06fd62ae54440e46", null ],
    [ "~CatmullClarkT", "a02677.html#ae84b68aef1eadc265af487ff3eaaa148", null ],
    [ "cleanup", "a02677.html#a083f82920d1b20c80fd34d0ccb566998", null ],
    [ "name", "a02677.html#a1f291ac6ca790e8cdc18697305cbd818", null ],
    [ "prepare", "a02677.html#a9becc2879f2bd7460a7e5459851c9a6e", null ],
    [ "subdivide", "a02677.html#ae629c898e1d24771d1e68cd3a4f27e4f", null ]
];