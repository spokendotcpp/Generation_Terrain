var a02693 =
[
    [ "generation", "a02693.html#a663f1fb7b0e9723b235c62ffde20aacb", null ],
    [ "inc_generation", "a02693.html#a7371c9e25e2d535371fa38e126500b7d", null ],
    [ "is_green", "a02693.html#a32717aaccd551b9f8a56fc22bd3ab495", null ],
    [ "is_red", "a02693.html#ad0702fbffd16e1c67c350ca1674f32ee", null ],
    [ "midpoint", "a02693.html#a555f591de31f97213d815e73c326e21d", null ],
    [ "position", "a02693.html#ae241a4c18c8f6c9363d5ec7711a7b833", null ],
    [ "quality", "a02693.html#a0a3351403e08860bc6b18b7437b44e6e", null ],
    [ "red_halfedge_handle", "a02693.html#a6c9f916a05b8e1757ad533effedeae89", null ],
    [ "set_generation", "a02693.html#aafb52d5713777efe039aa2fa7dd3e884", null ],
    [ "set_green", "a02693.html#a1f03d2b1307bd04192ae531c0a954ce9", null ],
    [ "set_midpoint", "a02693.html#a3ad0dd275c9f770a11254e6f4bc80cbe", null ],
    [ "set_position", "a02693.html#a1aa356342814ec9ceafd0583d1b18940", null ],
    [ "set_quality", "a02693.html#a0a4314f0e9df1159a4541e5095d24bc7", null ],
    [ "set_red", "a02693.html#a004cc994ef18f6d1d966e1a656473869", null ],
    [ "set_red_halfedge_handle", "a02693.html#ae67da24b36cfa093ab51beac81fc02b5", null ]
];