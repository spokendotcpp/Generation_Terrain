var a01809 =
[
    [ "IsTriangle", "a01809.html#a9b9e7c368e70361a6ee0e2d0ac7e3477", null ],
    [ "Refs", "a01809.html#abaa2dcfa0a57e6cf656f86d8ed312396", null ],
    [ "halfedge_handle", "a01809.html#a5bfc8ebda0cd1dadb9c643a66a7b178d", null ],
    [ "n_vertices", "a01809.html#a29cae853a8ee63813c28a3ade28f6eb2", null ],
    [ "set_halfedge_handle", "a01809.html#adbc031d4d4013dc5c462528f5d5c7380", null ],
    [ "set_n_vertices", "a01809.html#aa02b51765f9c2bd359647f4bde4098c9", null ]
];