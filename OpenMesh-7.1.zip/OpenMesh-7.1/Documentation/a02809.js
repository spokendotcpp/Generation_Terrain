var a02809 =
[
    [ "is_ancestor", "a02809.html#a23378dca1b5d038176edb65bae9bc4d7", null ],
    [ "set_vhierarchy_node_handle", "a02809.html#ac49c783c14ec6299eaed195aaaf90968", null ],
    [ "vhierarchy_node_handle", "a02809.html#ac353a7824801e051d845853a8b659c3d", null ]
];