var a02425 =
[
    [ "Base", "a02425.html#af8546d52b77726437395750b2eaa0cdb", null ],
    [ "CollapseInfo", "a02425.html#a67e401883de3a0ec5ecdc1bb7e7e8937", null ],
    [ "Handle", "a02425.html#a29ea31458ca5f541fc4d4c342ba9cd5a", null ],
    [ "Mesh", "a02425.html#a3864b942ad7a74c389fb283bd55d1d73", null ],
    [ "Point", "a02425.html#afad49f3a84130ebcc0a851cea2161739", null ],
    [ "Self", "a02425.html#ab05734e6a95d6e330c6d115a2af8dc19", null ],
    [ "value_type", "a02425.html#ae55ef761370282e939141ad9eaccd6ba", null ],
    [ "ModRoundnessT", "a02425.html#a6e56da8acf8ce9a37577c07764e5c98b", null ],
    [ "~ModRoundnessT", "a02425.html#a7b6ea799f3e162748ea4612654c56eb5", null ],
    [ "collapse_priority", "a02425.html#ade6fe704e576b3e0f73453ffd8cad0fd", null ],
    [ "name", "a02425.html#aa93e9089b4648365a2df1daabfe3da9c", null ],
    [ "roundness", "a02425.html#a589e3679e530a184543609d23c585bf6", null ],
    [ "set_error_tolerance_factor", "a02425.html#a14fa6c8dc43d6621a3c0cb5404e1a5de", null ],
    [ "set_min_angle", "a02425.html#ab33b28845de4cbd93fa21012522e9275", null ],
    [ "set_min_roundness", "a02425.html#a825e256b8e67059958ad809e9ace85c3", null ],
    [ "unset_min_roundness", "a02425.html#a1269b89dd5b20adbf0d81a7a86cc549b", null ]
];